# Technical GRC + AI Governance Portfolio

Hi, I'm Dhanvi Acharya. This repository is where I collect what I'm learning about **governance, risk and compliance (GRC)** from a technical point of view, with a growing focus on **governing AI systems, especially autonomous agents**.

Most GRC material stops at the policy. I'm interested in the next question: *what actually happens in the system when a control is in place, and how would you prove it?* A framework says "monitor your systems". A technical GRC person can say which logs, which detection rule, and which evidence satisfy that line. That gap is what I'm trying to learn to close.

> **Status:** work in progress. This is a learning portfolio, not professional audit or legal advice. Where I'm interpreting a framework rather than quoting it, I say so.

---

## What's in here

| Folder | What you'll find |
|---|---|
| [`/about`](./about) | Why I'm focused on technical GRC and AI governance, and what I'm working toward ([philosophy-and-goals.md](./about/philosophy-and-goals.md)) |
| [`/learnings`](./learnings) | Structured study notes, one per article I've published, plus supporting notes on cloud GRC and security monitoring |
| [`/projects`](./projects) | Applied GRC projects, added one at a time. **Project 1:** [AI governance assessment for a customer-facing AI agent](./projects/project-1-ai-governance-assessment) (control matrix across ISO 27001, EU AI Act and NIST AI RMF, guardrails, risk register) |
| [`/articles`](./articles) | PDF copies of the five pieces I've published on Substack |

## The thread running through the articles

Each piece asks the same question about a different place: **is cybersecurity and AI regulation built as a system, or does it accumulate as a patchwork?**

- **Canada** has a patchwork. The first two pieces look at the technical controls that matter ([01](./learnings/01-canada-critical-infrastructure-controls.md)) and at the six overlapping rules that govern AI in the absence of an AI law ([02](./learnings/02-canada-ai-governance-patchwork.md)).
- **The EU** designed a system on purpose: three laws that cross-reference each other ([03](./learnings/03-eu-cra-nis2-dora.md)).
- **India** has a patchwork by choice, which I read as three stacked layers plus a fourth axis for foreign clients ([04](./learnings/04-india-layered-cyber-governance.md)).
- **AI agents** are a new kind of principal that none of these frameworks was written for, so I look at them as an identity and monitoring problem ([05](./learnings/05-agentic-ai-and-nhis.md)).

## Start here

If you only have a few minutes:

1. **[Project 1: AI governance assessment](./projects/project-1-ai-governance-assessment)** turns the ideas below into a control matrix, guardrails specification and risk register for an AI agent.
2. **[05: Agentic AI and non-human identities](./learnings/05-agentic-ai-and-nhis.md)** is my most developed piece so far, with the full argument in [the article](./articles/05-identity-crisis-of-agentic-ai.pdf).
3. **[03: The EU's three cybersecurity laws](./learnings/03-eu-cra-nis2-dora.md)** is the clearest example of regulation designed as a system.
4. **[04: India's layered cyber governance](./learnings/04-india-layered-cyber-governance.md)** is the one to read if you work with Indian clients or vendors.

## Topics I cover

- **Regional cyber and AI regulation:** Canada, the EU (CRA, NIS2, DORA) and India (CERT-In, DPDP, SEBI/RBI), and how they differ in design
- **Technical controls as governance:** segmentation, backup resilience, MFA and secure remote access, with the standards that require them
- **AI governance:** agentic AI risk, non-human identities, the OWASP Agentic Top 10, and how NIST AI RMF, ISO/IEC 27001, SOC 2 and the EU AI Act relate to them
- **Cloud security and compliance foundations:** shared responsibility, Zero Trust, identity and the Microsoft security stack (I'm currently studying for the SC-900 exam)
- **Security operations as evidence:** SIEM and SOAR, logging and monitoring, and incident response mapped to audit requirements

## How I write these notes

- I read the primary source where I can and link it.
- I separate **what a framework says** from **my interpretation** of what it means in practice.
- I mark anything I haven't been able to verify, and I'd rather leave a gap than guess.
- If something is out of date or wrong, please tell me.

## Contact

- Substack: [add your Substack link]
- LinkedIn: [add your LinkedIn link]
- Email: [add your email, if you want it public]
