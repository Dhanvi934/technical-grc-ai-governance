import sys
from model import *
errs=[]
# 1 ids
for g in GUARDRAILS:
    for c in g["comps"]:
        if c not in COMP_IDS: errs.append(f"{g['id']}: unknown component {c}")
    for i in g["iso"]:
        if i not in ISO: errs.append(f"{g['id']}: unknown ISO control {i}")
    for n in g["nist"]:
        if n not in NIST: errs.append(f"{g['id']}: unknown NIST id {n}")
    for a in g["eu"]:
        if a not in EU_VALID: errs.append(f"{g['id']}: unknown EU article {a}")
    for a in g["asi"]:
        if not (a.startswith("ASI") and 1<=int(a[3:])<=10): errs.append(f"{g['id']}: bad ASI {a}")
if len({g['id'] for g in GUARDRAILS})!=len(GUARDRAILS): errs.append("duplicate guardrail ids")
for r in RISKS:
    if not r["grs"]: errs.append(f"{r['id']}: no guardrails")
    for x in r["grs"]:
        if x not in GR_IDS: errs.append(f"{r['id']}: unknown guardrail {x}")
    for c in r["comps"]:
        if c not in COMP_IDS: errs.append(f"{r['id']}: unknown component {c}")
    if sev(r["rl"],r["ri"])[0]>sev(r["li"],r["ii"])[0]: errs.append(f"{r['id']}: residual above inherent")
# 2 ISO excluded must not be mapped
m=iso_map()
for cid,(t,d,rs) in ISO.items():
    if d=="excl" and m.get(cid): errs.append(f"ISO {cid} excluded but mapped")
# 3 every guardrail addresses a risk?
used={x for r in RISKS for x in r["grs"]}
orph=[g["id"] for g in GUARDRAILS if g["id"] not in used]
# 4 EU rows' article refs
# 5 asi coverage
am=asi_map(); missing_asi=[f"ASI{n:02d}" for n in range(1,11) if f"ASI{n:02d}" not in am]
# 6 risk-asi coverage
rs=" ".join(r["asi"] for r in RISKS)
missing_risk_asi=[f"ASI{n:02d}" for n in range(1,11) if f"ASI{n:02d}" not in rs]
ir=iso_rows(); nr=nist_rows()
from collections import Counter
print("ISO",Counter(r["status"] for r in ir)); print("NIST",Counter(r["status"] for r in nr))
print("guardrails",len(GUARDRAILS),"risks",len(RISKS))
print("guardrails with no risk:",orph)
print("ASI without guardrail:",missing_asi,"| ASI without risk:",missing_risk_asi)
print("ISO base unmapped:",[r["id"] for r in ir if r["status"]=="base"])
print("NIST org unmapped:",[r["id"] for r in nr if r["status"]=="org"])
for e in errs: print("ERROR",e)
sys.exit(1 if errs else 0)
