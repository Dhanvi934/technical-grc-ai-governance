import csv, os, sys
from collections import Counter, defaultdict
from model import *

ROOT = sys.argv[1] if len(sys.argv)>1 else "out"
os.makedirs(f"{ROOT}/data",exist_ok=True)
def esc(s): return str(s).replace("|","\\|").replace("\n"," ")
def tbl(head,rows,align=None):
    o=["| "+" | ".join(head)+" |","|"+"|".join("---" for _ in head)+"|"]
    for r in rows: o.append("| "+" | ".join(esc(c) for c in r)+" |")
    return "\n".join(o)+"\n"
def j(x,sep=", "): return sep.join(x) if x else "-"
def w(path,text): open(f"{ROOT}/{path}","w",encoding="utf-8").write(text)
def csvw(path,head,rows):
    with open(f"{ROOT}/data/{path}","w",newline="",encoding="utf-8") as f:
        c=csv.writer(f); c.writerow(head); c.writerows(rows)

LAYERS=[]
for g in GUARDRAILS:
    if g["layer"] not in LAYERS: LAYERS.append(g["layer"])
ir=iso_rows(); nr=nist_rows()
isoc=Counter(r["status"] for r in ir); nistc=Counter(r["status"] for r in nr)
GBY={g["id"]:g for g in GUARDRAILS}
am=asi_map()
ASI_NAMES={"ASI01":"Agent Goal Hijack","ASI02":"Tool Misuse and Exploitation","ASI03":"Identity & Privilege Abuse",
 "ASI04":"Agentic Supply Chain Vulnerabilities","ASI05":"Unexpected Code Execution","ASI06":"Memory & Context Poisoning",
 "ASI07":"Insecure Inter-Agent Communication","ASI08":"Cascading Failures","ASI09":"Human-Agent Trust Exploitation","ASI10":"Rogue Agents"}

# ---------------------------------------------------------------- CSVs
csvw("control-matrix.csv",["guardrail_id","layer","guardrail","components","iso27001_annex_a","eu_ai_act","nist_ai_rmf","owasp_agentic_top10","evidence","test","status"],
     [[g["id"],g["layer"],g["title"],";".join(g["comps"]),";".join(g["iso"]),";".join(g["eu"]),";".join(g["nist"]),";".join(g["asi"]),g["evidence"],g["test"],"Designed"] for g in GUARDRAILS])
csvw("iso27001-soa.csv",["control","title","status","reason_for_inclusion_or_exclusion","guardrails"],
     [[r["id"],r["title"],r["label"],r["reason"],";".join(r["gr"])] for r in ir])
csvw("nist-ai-rmf-applicability.csv",["subcategory","topic","status","note","guardrails"],
     [[r["id"],r["topic"],r["label"],r["reason"] if r["status"]!="mapped" else "",";".join(r["gr"])] for r in nr])
em=eu_map()
def eu_codes(ref):
    if ref=="Art 18-19": return ["Art 18","Art 19"]
    if ref=="Art 43, 47, 49": return ["Art 49"]
    return [ref]
eu_out=[]
for ref,title,status,reason,cls in EU_ROWS:
    gs=sorted({x for c in eu_codes(ref) for x in em.get(c,[])})
    eu_out.append((ref,title,status,reason,gs))
csvw("eu-ai-act-applicability.csv",["article","title","status","reasoning","guardrails"],
     [[a,b,c,d,";".join(e)] for a,b,c,d,e in eu_out])
csvw("risk-register.csv",["risk_id","risk","owasp_agentic","description","cause","components","inherent_likelihood","inherent_impact","inherent_score","inherent_rating","guardrails","residual_likelihood","residual_impact","residual_score","residual_rating","owner","note"],
     [[r["id"],r["title"],r["asi"],r["desc"],r["cause"],";".join(r["comps"]),r["li"],r["ii"],sev(r["li"],r["ii"])[0],sev(r["li"],r["ii"])[1],";".join(r["grs"]),r["rl"],r["ri"],sev(r["rl"],r["ri"])[0],sev(r["rl"],r["ri"])[1],r["owner"],r["note"]] for r in RISKS])

# ---------------------------------------------------------------- 03 control matrix
o=["# 03: Control Matrix\n",
"One crosswalk from **guardrails** (things the system does) to the three frameworks. Each row is a guardrail with an ID. The columns show which ISO/IEC 27001:2022 Annex A controls, EU AI Act articles and NIST AI RMF subcategories it helps to meet, and which OWASP Agentic Top 10 risk it reduces.\n",
"> **How to read the mapping.** \"Maps to\" means the guardrail *contributes evidence toward* that control or requirement. It does not mean the guardrail alone satisfies it. ISO 27001 controls are met by the management system as a whole; the EU AI Act articles marked *design target* are voluntary here (see [02](./02-eu-ai-act-classification.md)); NIST AI RMF is a voluntary framework. The mappings are my reading, not an official crosswalk.\n",
"Machine-readable copy: [`data/control-matrix.csv`](./data/control-matrix.csv). Components (C1 to C16) are defined in [01-system-profile.md](./01-system-profile.md).\n",
"## Coverage at a glance\n"]
st=Counter(); 
o.append(tbl(["Framework","Items in framework","Mapped to a guardrail","Other handling"],[
 ["ISO/IEC 27001:2022 Annex A","93",f"{isoc['mapped']}",f"{isoc['base']} baseline ISMS control with no agent-specific guardrail; {isoc['inh']} inherited from providers; {isoc['excl']} excluded with reasons"],
 ["NIST AI RMF 1.0 subcategories","72",f"{nistc['mapped']}",f"{nistc['excl']} not covered (stated gaps); {nistc['org']} organisation-level"],
 ["EU AI Act (articles considered)",str(len(EU_ROWS)),str(sum(1 for x in eu_out if x[4])),"See [03b](./03b-eu-ai-act-applicability.md) for which are applicable, design targets, conditional or not applicable"],
 ["OWASP Agentic Top 10 (2026)","10",f"{sum(1 for k in ASI_NAMES if am.get(k))}","Every risk has at least one guardrail and one entry in the risk register"],
]))
o.append("\n**Reading the numbers.** A high mapped count in a design document shows the design has been thought through against the frameworks. It does not show the controls work. Every guardrail is at status *Designed*: nothing here is implemented, tested or audited. The `test` and `evidence` columns say what would have to be shown for the status to change.\n")
o.append("\n## OWASP Agentic Top 10 coverage\n")
o.append(tbl(["Risk","Name","Guardrails","Risks in register"],[[k,ASI_NAMES[k],j(sorted(am.get(k,[]))),j([r['id'] for r in RISKS if k in r['asi']])] for k in ASI_NAMES]))
for L in LAYERS:
    o.append(f"\n## {L}\n")
    rows=[[g["id"],g["title"],j(g["comps"]),j(g["iso"]),j(g["eu"]),j(g["nist"]),j(g["asi"])] for g in GUARDRAILS if g["layer"]==L]
    o.append(tbl(["ID","Guardrail","Components","ISO 27001 Annex A","EU AI Act","NIST AI RMF","OWASP"],rows))
o.append("\n## Detailed tables\n\n- [03a: ISO/IEC 27001 Statement of Applicability (all 93 controls)](./03a-iso-27001-statement-of-applicability.md)\n- [03b: EU AI Act applicability](./03b-eu-ai-act-applicability.md)\n- [03c: NIST AI RMF applicability (all 72 subcategories)](./03c-nist-ai-rmf-applicability.md)\n")
w("03-control-matrix.md","\n".join(o))

# ---------------------------------------------------------------- 03a ISO SoA
o=["# 03a: ISO/IEC 27001:2022 Statement of Applicability (design-level)\n",
f"All 93 Annex A controls, scoped to **{AGENT}** (the customer service agent described in [01](./01-system-profile.md)). A real Statement of Applicability covers the whole ISMS scope and is approved by management; this one shows how the same exercise looks for one AI system.\n",
"- **Included: agent-specific** means at least one guardrail contributes to the control (see the guardrail IDs).\n- **Included: baseline ISMS** means the organisation's existing control applies to the system, with no guardrail written specially for the agent.\n- **Inherited from provider** means the cloud or model provider operates the control and the evidence is their attestation (for example an ISO 27001 certificate or SOC 2 report), which the firm must review.\n- **Excluded** means not relevant to this system, with the reason.\n",
"Control titles follow the official ISO list (checked against a public listing). The \"Why it matters here\" column is my own wording; ISO's control text is copyrighted and is not reproduced. Buy the standard to read the real requirements.\n",
"The ISMS also requires the management-system clauses (4 to 10: context, leadership, planning including risk assessment and the SoA itself, support, operation, performance evaluation, improvement). This document covers Annex A only.\n",
tbl(["Status","Count"],[[ISO_LABEL[k],isoc[k]] for k in ["mapped","base","inh","excl"]])]
themes=[("5","Organisational controls"),("6","People controls"),("7","Physical controls"),("8","Technological controls")]
for t,name in themes:
    o.append(f"\n## {t}. {name}\n")
    o.append(tbl(["Control","Title","Status","Why it matters here","Guardrails"],[[r["id"],r["title"],r["label"],r["reason"],j(r["gr"])] for r in ir if r["theme"]==t]))
w("03a-iso-27001-statement-of-applicability.md","\n".join(o))

# ---------------------------------------------------------------- 03b EU
o=["# 03b: EU AI Act Applicability\n",
"Article-by-article view of what applies to this system and why. The reasoning behind the classification is in [02](./02-eu-ai-act-classification.md). This is my interpretation for a learning project, not legal advice.\n",
"Status key: **Applies** (binding on the firm for this system), **Design target** (binding only on high-risk systems; adopted voluntarily), **Conditional** (becomes binding if scope changes), **Not applicable**, **Note** (open question or context).\n",
tbl(["Article","Title","Status","Reasoning","Guardrails"],[[a,b,c,d,j(e)] for a,b,c,d,e in eu_out])]
w("03b-eu-ai-act-applicability.md","\n".join(o))

# ---------------------------------------------------------------- 03c NIST
o=["# 03c: NIST AI RMF 1.0 Applicability\n",
"All 72 subcategories across Govern, Map, Measure and Manage. Subcategory topics are my short paraphrases. NIST AI RMF is voluntary, so the question here is not \"does it apply\" but \"does the design address it, and where does it not\".\n",
tbl(["Status","Count"],[[NIST_LABEL[k],nistc[k]] for k in ["mapped","excl","org"]]),
"\nThe rows marked **not covered** are honest gaps in this design, not oversights hidden by a mapping. They are listed again in the README under limitations.\n"]
for fn in ["GOVERN","MAP","MEASURE","MANAGE"]:
    o.append(f"\n## {fn.title()}\n")
    o.append(tbl(["Subcategory","Topic","Status","Guardrails / note"],[[r["id"],r["topic"],r["label"],j(r["gr"]) if r["status"]=="mapped" else r["reason"]] for r in nr if r["fn"]==fn]))
w("03c-nist-ai-rmf-applicability.md","\n".join(o))

# ---------------------------------------------------------------- 05 risk register
o=["# 05: Risk Register and Threat Model\n",
f"Twenty risks for {AGENT}. Ten come from the OWASP Top 10 for Agentic Applications 2026 (a published taxonomy of agent risks, not a standard); ten are additional risks I judged relevant to a customer-facing service agent in a regulated firm.\n",
"## How the scores work\n",
"Likelihood and impact are each scored 1 to 5 (1 very low, 5 very high). The score is likelihood times impact: **Low** up to 5, **Medium** 6 to 11, **High** 12 to 19, **Critical** 20 and above. These are my judgements for a hypothetical system, not measurements. **Residual** scores assume the mapped guardrails are implemented and working as specified. Since nothing is implemented, treat residual scores as targets to be proved by the tests in [04](./04-guardrails-specification.md), not as achieved results.\n",
"Machine-readable copy: [`data/risk-register.csv`](./data/risk-register.csv). Chart: [images/03-risk-heatmap.png](./images/03-risk-heatmap.png).\n",
"![Inherent and residual risk heat maps](./images/03-risk-heatmap.png)\n",
"## Summary\n"]
rows=[]
for r in RISKS:
    s1,l1=sev(r["li"],r["ii"]); s2,l2=sev(r["rl"],r["ri"])
    rows.append([r["id"],r["title"],r["asi"],f"{r['li']}x{r['ii']} = {s1} ({l1})",f"{r['rl']}x{r['ri']} = {s2} ({l2})",r["owner"]])
o.append(tbl(["ID","Risk","OWASP","Inherent","Residual (target)","Owner (role)"],rows))
c1=Counter(sev(r["li"],r["ii"])[1] for r in RISKS); c2=Counter(sev(r["rl"],r["ri"])[1] for r in RISKS)
o.append("\n"+tbl(["Rating","Inherent","Residual (target)"],[[k,c1.get(k,0),c2.get(k,0)] for k in ["Critical","High","Medium","Low"]]))
o.append("\n## Risk detail\n")
for r in RISKS:
    s1,l1=sev(r["li"],r["ii"]); s2,l2=sev(r["rl"],r["ri"])
    o.append(f"### {r['id']}: {r['title']}\n")
    o.append(f"- **OWASP:** {r['asi']}\n- **What could happen:** {r['desc']}\n- **Why:** {r['cause']}\n- **Components:** {j(r['comps'])}\n- **Inherent:** likelihood {r['li']}, impact {r['ii']}, score {s1} ({l1})\n- **Treated by:** {j(r['grs'])}\n- **Residual (target):** likelihood {r['rl']}, impact {r['ri']}, score {s2} ({l2})\n- **Owner (role):** {r['owner']}\n"+(f"- **Note:** {r['note']}\n" if r['note'] else "")+"\n")
w("05-risk-register.md","\n".join(o))
print("ok",ROOT, dict(isoc),dict(nistc),dict(c1),dict(c2))

# ---------------------------------------------------------------- 04 guardrails spec
g2r=defaultdict(list)
for r in RISKS:
    for x in r["grs"]: g2r[x].append(r["id"])
cname={c[0]:c[1] for c in COMPONENTS}
o=["# 04: Guardrails Specification\n",
f"What {AGENT} must do, in testable terms. Forty-six guardrails in seven layers. Each has an ID that appears in the [control matrix](./03-control-matrix.md) and the [risk register](./05-risk-register.md), the component where it is enforced, the evidence that would show it works, and a test.\n",
"**Status of everything here: Designed.** Nothing is built. The configuration snippets are illustrative shapes, not tested code.\n",
"## Design rules behind the guardrails\n",
"1. **Enforce outside the model.** A prompt can ask the model to behave. Only code outside the model (authorisation service, tool servers, network policy) can make it. Where a guardrail says \"enforced in\" a component, that component is not the LLM.\n2. **Authorise against the user.** The agent never has more rights than the customer it is serving.\n3. **One identity per agent, short-lived credentials, scoped per tool server.** Revoking one agent must not break the others.\n4. **Tier every action.** What the agent may do alone, with the customer's confirmation, or with a person's approval is a table, not a sentence in a prompt.\n5. **Log so an incident can be reconstructed.** If it is not logged with who, for whom, what and outcome, it did not happen as far as an auditor is concerned.\n",
"## Action tiers (G-06)\n",
tbl(["Tier","Meaning","Examples","Needs","Human approval"],[list(t) for t in ACTION_TIERS]),
"\n## Illustrative configuration\n",
"### Tool register (G-06, G-07, G-14)\n",
"```yaml\n# tool-register.yaml : illustrative\ntools:\n  - name: get_balance\n    server: accounts-mcp\n    agent: specialist-a\n    tier: 1\n    scopes: [accounts:read]\n    limits: {max_accounts: 5}\n  - name: freeze_card\n    server: cards-mcp\n    agent: specialist-b\n    tier: 2\n    requires: [user_confirmation]\n  - name: change_postal_address\n    server: requests-mcp\n    agent: specialist-c\n    tier: 3\n    requires: [step_up_auth, human_approval]\n    approval: {queue: staff-approvals, expires_minutes: 30, show: exact_change}\n# Deliberately absent: any tool for credit, lending, insurance pricing or investment decisions (G-14).\n# A tool with no tier cannot be registered.\n```\n",
"### Authorisation rules (G-02, G-04, G-10)\n",
"```yaml\n# policy: tool_call_authorisation : illustrative\ninputs: [end_user_id, agent_id, tool, record_owner_id, tier, auth_level, user_confirmed, approval_id]\nrules:\n  - deny if: record_owner_id != end_user_id          # confused-deputy check\n  - deny if: tool not in allowlist[agent_id]         # G-07\n  - deny if: tier >= 2 and not user_confirmed        # G-10\n  - deny if: tier == 3 and (auth_level != step_up or approval_id is null)   # G-01, G-09\n  - otherwise: allow, and write the decision to the audit log\n```\n",
"### Audit log record (G-29, G-20)\n",
"```json\n{\n  \"ts\": \"2026-11-03T09:14:22.381Z\",\n  \"session\": \"s_8f21\",\n  \"customer\": \"cust_tok_4b7a\",\n  \"agent_id\": \"specialist-b\",\n  \"tool\": \"freeze_card\",\n  \"tier\": 2,\n  \"params\": {\"card\": \"card_tok_91c2\"},\n  \"authz\": {\"decision\": \"allow\", \"policy_version\": \"2026.11.1\"},\n  \"user_confirmed\": true,\n  \"approval_id\": null,\n  \"outcome\": \"success\",\n  \"model\": {\"name\": \"third-party-llm\", \"version\": \"pinned-2026-10\"},\n  \"prompt_version\": \"p-0042\"\n}\n```\n",
"### Detection rules for SIEM (G-31)\n",
tbl(["Rule","Fires when","Response"],[
 ["Cross-customer attempt","Authorisation denies a call where the record owner differs from the end user","Alert; after 3 in a session, suspend session and review"],
 ["Tool-call burst","An agent's calls per minute exceed its baseline by a set factor","Throttle; alert"],
 ["Instruction in data","Injection detector flags instruction-like text in a retrieved document or tool result","Log; strip; alert if repeated"],
 ["New identity or tool","An agent identity or tool appears that is not in the register","Block; page security"],
 ["Tier 3 anomaly","Tier 3 requests out of hours, or a spike in approvals per approver","Hold; second reviewer"],
 ["Repeated denials","The same agent is denied repeatedly on the same tool","Investigate for injection or misconfiguration"],
 ["Cost runaway","Tokens or steps for a session exceed the cap","Stop session; alert"]]),
"\n### Kill switch levels (G-32)\n",
tbl(["Level","Effect","Who can trigger"],[
 ["Session","End one conversation and hand to a person","Agent, staff, SOAR"],
 ["Tool","Disable one tool for everyone","On-call engineer, security"],
 ["Agent","Suspend one specialist and revoke its credentials","Security lead"],
 ["System","Route all customers to static FAQ and human handoff","Incident commander"]]),
]
for L in LAYERS:
    o.append(f"\n## {L}\n")
    for g in GUARDRAILS:
        if g["layer"]!=L: continue
        o.append(f"### {g['id']}: {g['title']}\n")
        o.append(f"**What it does.** {g['what']}\n")
        o.append(f"- **Enforced in:** {', '.join(g['comps'])} ({'; '.join(cname[c] for c in g['comps'])})\n- **Maps to:** ISO 27001 {j(g['iso'])} · EU AI Act {j(g['eu'])} · NIST AI RMF {j(g['nist'])} · OWASP {j(g['asi'])}\n- **Reduces risk:** {j(g2r[g['id']])}\n- **Evidence:** {g['evidence']}\n- **Test:** {g['test']}\n")
w("04-guardrails-specification.md","\n".join(o))
print("04 written")

# ---------------------------------------------------------------- 01 system profile
nG=len(GUARDRAILS); nR=len(RISKS)
o=[f"# 01: System Profile\n",
f"The system this assessment is about. **{FIRM}** is an invented company; nothing here describes a real firm or product.\n",
"## The system in one paragraph\n",
f"**{AGENT}** is a customer-facing chat agent for a regulated financial firm that serves customers in the EU. Customers sign in and ask it things like \"what is my balance\", \"send me last month's statement\", \"freeze my card\" or \"change my address\". A coordinator agent routes each request to one of three specialist agents (accounts, cards, service requests). Each specialist calls tools through its own tool server, which talks to the firm's back-end systems. The model behind the agents is a mix of a self-hosted model and a third-party LLM API.\n",
"## Scope\n",
tbl(["In scope","Out of scope (the agent refuses and hands to a person)"],[
 ["Answering product and policy questions from approved sources","Credit, lending or overdraft decisions; creditworthiness assessment"],
 ["Reading the customer's own balance, transactions, statements, card status","Insurance risk assessment or pricing"],
 ["Reversible changes with confirmation: log a dispute, order a statement, freeze a card, update contact preferences","Investment, tax or legal advice"],
 ["Sensitive changes with step-up and staff approval: change address or phone, replace a card, change limits","Moving money to a new payee; closing accounts"],
 ["Handing the conversation to a person","Fraud adjudication and sanctions decisions (done by staff and other systems)"]]),
"\nThe scope line matters for regulation as well as for safety. Excluding credit and insurance decisions is what keeps the system out of the EU AI Act's high-risk list (see [02](./02-eu-ai-act-classification.md)).\n",
"## Roles\n",
"- **The firm** builds the agent from a third-party model and its own components and puts it into service under its own name. Under the EU AI Act that likely makes it both **provider** (of the AI system) and **deployer**. That is my reading; the role analysis is in 02.\n- **Model supplier** (third-party LLM API) is a supplier of a general-purpose model; the firm depends on their documentation and terms (G-26).\n- **Cloud provider** hosts the runtime (physical controls are inherited, see 03a).\n- **Customers** are the affected persons.\n- **Staff:** service agents who take handoffs, and approvers for Tier 3 actions.\n",
"## Data\n",
tbl(["Data","Examples","Where it appears"],[
 ["Identity and contact","Name, address, phone, email","Session, tool results, approval console"],
 ["Financial","Balances, transactions, statements, card status and limits","Tool results, model context (tokenised where possible), logs (tokenised)"],
 ["Conversation","What the customer typed and the agent replied","Session store, logs, model provider (redacted)"],
 ["Operational","Agent actions, tool calls, decisions, approvals","Audit log, SIEM"]]),
"\n## Architecture\n",
"![Reference architecture with component IDs](./images/01-architecture-component-ids.png)\n",
"The base design is a generic multi-agent pattern (user interface, edge layer, identity provider, authorisation, PII redaction, coordinator, specialists with their own tool servers, session store, model layer, evaluation, cost tracking and observability feeding a SIEM). I added a human approval and handoff console (C16) and split the backend by action tier. [add the source of the base architecture diagram if you reuse one]\n",
"### Components\n",
tbl(["ID","Component","What it does"],[list(c) for c in COMPONENTS]),
"\n### Two requests, end to end\n",
"**\"What is my balance?\" (Tier 1).** 1) The customer is signed in through C3 with MFA (G-01). 2) C2 applies rate limits; C4 passes the message and user token on. 3) C6 replaces any account numbers with tokens (G-20). 4) C7 decides this is an accounts question and hands it to Specialist A. 5) Specialist A asks Tool server A for the balance using its own short-lived token (G-03, G-04). 6) C5 checks that this user may read this account (G-02). 7) The tool server returns the balance, the reply is checked (G-18) and shown with the AI notice already on screen (G-15). 8) Every step is written to the audit log with tokenised identifiers (G-29).\n",
"**\"Change my address\" (Tier 3).** Steps 1 to 6 as above, then: the agent shows the exact change and asks the customer to confirm, and C3 asks for step-up authentication (G-10, G-01). The request goes to the approval queue in C16 (G-09). A staff approver sees the exact change, approves or rejects, and the decision is logged. Only then does Tool server C make the change. The customer gets an out-of-band notification. If anything fails or the model path is down, the customer is offered a person (G-19, G-28).\n",
"## Trust boundaries\n",
"- **Customer to edge (C1 to C2).** Everything the customer sends is untrusted.\n- **Agent system to model layer (C7/C8 to C12).** Text leaving for the third-party model crosses a company boundary; only redacted text goes (G-20).\n- **Agent to tool servers (C8 to C9).** The agent is not trusted to enforce limits; tool servers and C5 do.\n- **Tool servers to backends (C9 to C10).** Narrow, tiered credentials.\n- **Staff console (C16).** Privileged: only trained, authorised staff; every action logged.\n- **Retrieved content and tool output.** Untrusted data, never instructions (G-13).\n",
"## Assumptions\n",
"- The firm is a regulated financial services firm in the EU; sector rules on ICT risk, incident reporting and outsourcing (DORA, NIS2) also apply but are outside this assessment.\n- Customers are individuals; no business customers.\n- The agent cannot send money to a new payee. This is a deliberate limit to keep the first version low-risk.\n- No emotion recognition, biometric identification or profiling is used.\n- Hosting is on a cloud provider with current security attestations, and the firm already runs an ISMS.\n- Nothing is built. This is a design.\n"]
w("01-system-profile.md","\n".join(o))

# ---------------------------------------------------------------- 02 classification
o=[f"# 02: EU AI Act Classification\n",
"How I would classify the service agent under Regulation (EU) 2024/1689 (the EU AI Act), step by step, and what that means for the project. **This is my interpretation for a learning project, not legal advice.** A real classification would be made with legal counsel and recorded in the system register (G-40).\n",
"![EU AI Act classification flow](./images/02-eu-ai-act-classification-flow.png)\n",
"## Step 1: Is it an AI system?\n",
"An LLM-based agent that takes input and infers how to generate outputs (replies, tool calls) that influence what happens next is an AI system as the Act defines it. Yes.\n",
"## Step 2: Prohibited practices (Article 5)\n",
"Article 5 bans certain practices outright, including AI that uses manipulative techniques or exploits vulnerabilities to distort behaviour in harmful ways (Art 5(1)(a) and (b)). A customer-facing financial agent is a place where this could happen by accident (pressure, urgency, exploiting a customer's age, disability or financial situation, which Art 5(1)(b) names). So the project treats Article 5 as a design check, not a formality: G-16 forbids manipulation and, as a design heuristic, routes signs of vulnerability or distress to a person, and no emotion inference is used. Answer: no prohibited practice intended; keep checking.\n",
"## Step 3: Annex III high-risk areas\n",
"High-risk AI under Article 6(2) means the use cases listed in Annex III. The area closest to this system is **essential private services**: point 5(b) covers AI used to evaluate the creditworthiness of natural persons or establish their credit score (excluding fraud detection), and 5(c) covers risk assessment and pricing for life and health insurance. The service agent does neither: it answers questions, reads the customer's own records and performs bounded service actions. G-14 enforces the boundary with a classifier and, more importantly, with tool design: no tool exists that makes credit or insurance decisions. Answer: not Annex III, **as long as the scope holds**.\n",
"Article 6(3) lets a provider conclude that an Annex III system is not high-risk in narrow cases, but only after documenting the assessment, and it never applies to profiling of natural persons. The project does not rely on it.\n",
"## Step 4: Transparency (Article 50)\n",
"Article 50(1) requires providers to design AI systems that interact directly with people so that those people are told they are dealing with an AI system, unless that is obvious from the circumstances. A customer service chat is exactly that. This is the one new transparency obligation that clearly binds this system (Arts 4 and 5 also apply). Guardrail G-15 delivers it. Article 50 applies from 2 August 2026.\n",
"Article 50(2) (machine-readable marking of synthetic content) names audio, image, video **and text**. Whether it reaches individual replies in a service chat is, to my knowledge, an open interpretation question, so I flag it rather than answer it (see 03b).\n",
"## Result\n",
tbl(["Question","Answer","Consequence"],[
 ["High-risk?","No, provided scope excludes Annex III 5(b) and 5(c) uses","Arts 8 to 27 are not binding obligations"],
 ["Limited-risk (transparency)?","Yes","Art 50(1) applies now"],
 ["Other binding duties?","Art 4 AI literacy; Art 5 prohibitions","G-43, G-16"],
 ["Voluntary design targets?","Yes","Arts 9 to 15, 17 and deployer practice are used as the design baseline"]]),
"\n**Why adopt high-risk requirements voluntarily?** Article 95 encourages voluntary application of such requirements. More practically, they are a good published method for risk management, logging, human oversight and robustness, and they are what the firm would need immediately if scope ever grew. Designing to that standard is cheaper than retrofitting.\n",
"## Key dates (as I understand them, check before relying)\n",
tbl(["Date","What","Source of my understanding"],[
 ["2 Feb 2025","Art 4 AI literacy and Art 5 prohibitions apply (penalty provisions later, from 2 Aug 2025: to check)","AI Act application schedule"],
 ["27 Jul 2026","AI Omnibus amending the Act in force (published in the Official Journal 24 Jul 2026; cited as Regulation (EU) 2026/1744 in one secondary source)","Law-firm summaries; I have not read the Official Journal text myself"],
 ["2 Aug 2026","Art 50 transparency obligations apply","AI Act application schedule"],
 ["2 Dec 2026","Grace period ends for Art 50(2) marking, only for generative systems placed on the market before 2 Aug 2026 (a new system gets none). The Omnibus also adds new Art 5 bans from this date (non-consensual intimate imagery and child sexual abuse material generators), which do not affect this system","Law-firm summaries of the Omnibus"],
 ["2 Dec 2027","Annex III high-risk obligations apply (moved by the Omnibus)","Law-firm summaries of the Omnibus"],
 ["2 Aug 2028","Annex I (product-linked) high-risk obligations apply","Law-firm summaries of the Omnibus"]]),
"\n## What would change the answer\n",
tbl(["Change in scope","Effect","Guardrails and risk"],[
 ["Agent gives credit-limit increase or loan-eligibility guidance that feeds a decision","Likely Annex III 5(b): high-risk. Arts 8 to 27 apply; FRIA (Art 27)","G-14, G-40, R-15"],
 ["Agent prices or advises on life or health insurance","Annex III 5(c): high-risk","G-14, G-40, R-15"],
 ["Agent uses emotion inference on customers","Emotion recognition is high-risk under Annex III 1(c) with Art 50(3) disclosure; Art 5(1)(f) prohibits it only in workplace and education settings","G-16"],
 ["Agent moves money to new payees","Not an AI Act trigger by itself; large security and DORA impact","Tier table, G-06"],
 ["Firm stops building and buys a finished agent product","Roles follow the Art 3 definitions: the firm would be a deployer and the supplier the provider; Art 25 applies only if the firm puts its name on the product or substantially modifies it","G-26"]]),
"\n## Adjacent regimes (not assessed in this project)\n",
"- **GDPR** applies to all the personal data in the system. The data-protection impact assessment, lawful basis, data-subject rights and the rules on solely automated decisions (Art 22) sit alongside the AI Act. G-42 includes a DPIA.\n- **DORA** applies to the firm as a financial entity: ICT risk management, incident reporting, third-party risk (including the model and cloud providers).\n- **NIS2** may apply depending on sector and size.\n- **Consumer-protection and sector conduct rules** apply to what the agent says about products and fees (G-17).\n",
"## Open questions\n",
"- Does Art 50(2) marking apply to chat replies in a service channel?\n- If the firm builds on a third-party general-purpose model, how do the model supplier's obligations and the firm's provider role fit together in practice (Art 25)?\n- The Omnibus article-level text should be checked in the Official Journal before any of the dates above are used for planning.\n",
"## Sources\n",
"- Regulation (EU) 2024/1689 (EU AI Act), EUR-Lex: https://eur-lex.europa.eu/eli/reg/2024/1689/oj\n- AI Omnibus: law-firm summaries (CMS, Goodwin); official text to be read from the Official Journal.\n"]
w("02-eu-ai-act-classification.md","\n".join(o))

# ---------------------------------------------------------------- README
mapped_asi=sum(1 for k in ASI_NAMES if am.get(k))
o=[f"# Project 1: AI Governance Assessment for a Customer-Facing AI Agent\n",
"A design-level compliance assessment for an AI agent system: **what would it take for an agentic customer-service system to line up with ISO/IEC 27001, the EU AI Act and the NIST AI RMF, and how would you prove it?**\n",
"> **Status: Designed, not built.** This is a paper design of a hypothetical system at an invented firm. No agent has been implemented, tested or audited. \"Compliant\" is a property of a real, running, evidenced system; this project defines what that would require and what evidence would show it. The framework mappings are my interpretation, not an official crosswalk, and this is not legal or audit advice.\n",
"## The scenario\n",
f"**{AGENT}** is a customer-facing chat agent at **{FIRM}**, a regulated firm with EU customers. It answers questions, reads the customer's own data and performs bounded service actions through specialist agents and tool servers. Full profile in [01-system-profile.md](./01-system-profile.md).\n",
"![Architecture](./images/01-architecture-component-ids.png)\n",
"## What is in this project\n",
tbl(["File","What it is"],[
 ["[01-system-profile.md](./01-system-profile.md)","Scope, roles, data, components (C1 to C16), data flows, trust boundaries, assumptions"],
 ["[02-eu-ai-act-classification.md](./02-eu-ai-act-classification.md)","Why the agent is not high-risk under the EU AI Act, which duties still bind it, and what would change the answer"],
 ["[03-control-matrix.md](./03-control-matrix.md)",f"The matrix: {nG} guardrails mapped to ISO 27001 Annex A, EU AI Act articles, NIST AI RMF subcategories and the OWASP Agentic Top 10"],
 ["[03a ISO 27001 Statement of Applicability](./03a-iso-27001-statement-of-applicability.md)","All 93 Annex A controls: included, inherited or excluded, with reasons"],
 ["[03b EU AI Act applicability](./03b-eu-ai-act-applicability.md)","Article-by-article: applies, design target, conditional, not applicable"],
 ["[03c NIST AI RMF applicability](./03c-nist-ai-rmf-applicability.md)","All 72 subcategories, with stated gaps"],
 ["[04-guardrails-specification.md](./04-guardrails-specification.md)","Each guardrail: what it does, where it is enforced, evidence, test; illustrative configuration"],
 ["[05-risk-register.md](./05-risk-register.md)",f"{nR} risks and threat model with inherent and residual scores and heat maps"],
 ["[data/](./data)","The same tables as CSV"],
 ["[tools/](./tools)","The Python that generates the tables and checks them (see below)"]]),
"\n## Results at a glance\n",
tbl(["Measure","Result"],[
 ["Guardrails",f"{nG}, in {len(LAYERS)} layers, each with evidence and a test"],
 ["ISO/IEC 27001:2022 Annex A",f"{isoc['mapped']} of 93 controls have agent-specific guardrails; {isoc['base']} apply as baseline ISMS; {isoc['inh']} inherited from providers; {isoc['excl']} excluded with reasons"],
 ["NIST AI RMF 1.0",f"{nistc['mapped']} of 72 subcategories mapped; {nistc['excl']} stated gaps; {nistc['org']} organisation-level"],
 ["EU AI Act",f"Not high-risk (scope excludes Annex III 5(b) and 5(c)); Art 50(1) disclosure, Art 4 literacy and Art 5 checks apply; Arts 9 to 15 and deployer practice adopted as design targets"],
 ["OWASP Agentic Top 10",f"{mapped_asi} of 10 risks covered by guardrails and by the risk register"],
 ["Risk register",f"{nR} risks: inherent {c1.get('High',0)} high and {c1.get('Medium',0)} medium; residual target {c2.get('Medium',0)} medium and {c2.get('Low',0)} low if guardrails work as specified"]]),
"\nA high mapped count in a design document shows the design was thought through against the frameworks. It does not show the controls work. The test column in each guardrail says what would have to be demonstrated.\n",
"## How I built it\n",
"1. **Start from the architecture, not the frameworks.** The components are numbered (C1 to C16).\n2. **Write guardrails first.** Each is a thing the system does, with a component, evidence and a test. Reasoning: frameworks do not describe agents, so I wrote the agent controls myself and then asked which framework requirements each one supports.\n3. **Map outward.** Each guardrail lists the ISO Annex A controls, EU AI Act articles and NIST subcategories it contributes to, and the OWASP agent risk it reduces.\n4. **Do the exclusions honestly.** Every ISO and NIST item that is not covered by a guardrail is listed with a status and a reason.\n5. **Generate and check.** All tables come from one data source. A validation script checks that every referenced ID exists, every risk has a guardrail, and no excluded control is also mapped.\n",
"## Design principles\n",
"- Enforce outside the model: authorisation, limits and network rules live in code, not in a prompt.\n- Authorise against the user: the agent never has more rights than the customer.\n- One identity per agent, short-lived scoped credentials.\n- Tier every action: alone, with confirmation, or with a person's approval.\n- Log so an incident can be reconstructed.\n",
"## Limitations and known gaps\n",
"- **Nothing is implemented or tested.** Status of every guardrail is *Designed*; residual risk scores are targets, not results.\n- **The scores are my judgement** on a 1 to 5 scale for a hypothetical system.\n- **\"Mapped\" means contributes toward, not satisfies.** ISO controls are met by the whole management system.\n- **ISO management-system clauses (4 to 10)** are not assessed; only Annex A.\n- **ISO 27001 text is not reproduced.** Titles are official; descriptions are my words.\n- **Dates and Omnibus changes** to the EU AI Act come from secondary sources and should be checked against the Official Journal. The Art 50(2) question is open.\n- **Not covered, by design:** GDPR, DORA and NIS2 (noted in 02); ISO/IEC 42001 (the AI management-system standard).\n- **NIST AI RMF gaps:** engagement with affected people (MAP 5.2), sustaining value (MANAGE 2.2), environmental impact (MEASURE 2.12), human-subject evaluations (MEASURE 2.2), fairness and bias evaluation (MEASURE 2.11), and the business-case items (MAP 1.4, MAP 3.1).\n- **The base architecture** follows a common multi-agent reference pattern; credit its source if you reuse a diagram.\n",
"## Reproduce\n",
"```bash\npython tools/validate.py        # cross-reference checks and coverage numbers\npython tools/build.py .         # regenerates the tables and documents from the data files\npython tools/gen_figs.py images # regenerates the figures (needs Playwright with Chromium)\n```\n",
"Edit `tools/data_core.py`, `data_iso.py` or `data_nist.py` to change content, then rebuild. The `.md` files here are generated; edits made directly to them will be overwritten.\n",
"## Sources\n",
"- ISO/IEC 27001:2022: https://www.iso.org/standard/27001\n- EU AI Act, Regulation (EU) 2024/1689: https://eur-lex.europa.eu/eli/reg/2024/1689/oj\n- NIST AI Risk Management Framework 1.0: https://www.nist.gov/itl/ai-risk-management-framework\n- OWASP Top 10 for Agentic Applications 2026: https://genai.owasp.org/\n",
"## Related notes in this portfolio\n",
"- [05: Agentic AI and non-human identities](../../learnings/05-agentic-ai-and-nhis.md) is the argument behind the identity and monitoring guardrails.\n- [03: The EU's three cybersecurity laws](../../learnings/03-eu-cra-nis2-dora.md) covers DORA and NIS2, which sit next to the AI Act for a financial firm.\n"]
w("README.md","\n".join(o))
print("docs written")
