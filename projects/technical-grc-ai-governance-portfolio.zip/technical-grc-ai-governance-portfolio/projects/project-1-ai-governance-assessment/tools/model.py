from collections import defaultdict
from data_core import *
from data_iso import ISO
from data_nist import NIST

def iso_map():
    m=defaultdict(list)
    for g in GUARDRAILS:
        for i in g["iso"]: m[i].append(g["id"])
    return m
def nist_map():
    m=defaultdict(list)
    for g in GUARDRAILS:
        for i in g["nist"]: m[i].append(g["id"])
    return m
def eu_map():
    m=defaultdict(list)
    for g in GUARDRAILS:
        for a in g["eu"]: m[a].append(g["id"])
    return m
def asi_map():
    m=defaultdict(list)
    for g in GUARDRAILS:
        for a in g["asi"]: m[a].append(g["id"])
    return m

ISO_LABEL={"mapped":"Included: agent-specific","base":"Included: baseline ISMS","inh":"Inherited from provider","excl":"Excluded"}
def iso_rows():
    m=iso_map(); rows=[]
    for cid,(title,default,reason) in ISO.items():
        gs=m.get(cid,[])
        st="mapped" if gs else default
        rows.append(dict(id=cid,theme=cid.split(".")[0],title=title,status=st,label=ISO_LABEL[st],reason=reason,gr=gs))
    return rows
NIST_LABEL={"mapped":"Mapped to guardrails","org":"Organisation-level, no runtime guardrail","excl":"Not covered (stated gap)"}
def nist_rows():
    m=nist_map(); rows=[]
    for cid,(topic,default,reason) in NIST.items():
        gs=m.get(cid,[])
        st="mapped" if gs else default
        rows.append(dict(id=cid,fn=cid.split()[0],topic=topic,status=st,label=NIST_LABEL[st],reason=reason,gr=gs))
    return rows
def sev(l,i):
    s=l*i
    return s,("Critical" if s>=20 else "High" if s>=12 else "Medium" if s>=6 else "Low")
