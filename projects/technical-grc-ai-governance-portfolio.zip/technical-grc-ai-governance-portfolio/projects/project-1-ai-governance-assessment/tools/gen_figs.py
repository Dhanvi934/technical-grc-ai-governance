import sys
from collections import defaultdict
from model import *
OUT = sys.argv[1] if len(sys.argv)>1 else "out/images"
import os, tempfile; os.makedirs(OUT,exist_ok=True); TMP=tempfile.mkdtemp()
C = dict(blue="#2a78d6", bluebg="#e8f0fb", green="#0f8f63", greenbg="#e3f5ee", orange="#c9601f", orangebg="#fbeee4",
         gray="#85837c", graybg="#f1f1ef", violet="#4a3aa7", violetbg="#ece9f8", red="#b3372f", redbg="#f9e7e5", ink="#0b0b0b", ink2="#3d3d3b")
FONT='font-family="Helvetica Neue,Arial,sans-serif"'
HEAD='''<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fcfcfb;font-family:"Helvetica Neue",Arial,sans-serif;color:#0b0b0b}
.canvas{padding:32px;background:#fcfcfb;display:inline-block}
h2{font-size:21px;margin:0 0 4px;font-weight:700} p.s{font-size:13px;color:#3d3d3b;margin:0 0 18px;max-width:980px;line-height:1.5}
.key{display:flex;gap:18px;margin-top:12px;font-size:11px;color:#3d3d3b;flex-wrap:wrap}.key span{display:flex;align-items:center;gap:6px}.key i{width:14px;height:14px;border-radius:3px;border:1.5px solid;display:inline-block}
.note{font-size:11.5px;color:#3d3d3b;margin-top:12px;max-width:1000px;line-height:1.5}
svg{display:block}
</style></head><body>'''
def esc(s): return s.replace("&","&amp;").replace("<","&lt;")

# ---------------- Figure 1: architecture with component IDs
o=[]
def box(x,y,w,h,lines,kind="blue",bold=True,fs=12.5):
    o.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="7" fill="{C[kind+"bg"]}" stroke="{C[kind]}" stroke-width="1.5"/>')
    n=len(lines); lh=fs+3; y0=y+h/2-(n-1)*lh/2+fs*0.35
    for i,t in enumerate(lines):
        o.append(f'<text x="{x+w/2}" y="{y0+i*lh}" text-anchor="middle" font-size="{fs if i==0 else fs-1.5}" font-weight="{700 if (i==0 and bold) else 400}" fill="{C["ink"]}">{esc(t)}</text>')
def line(d,dash=False):
    o.append(f'<path d="{d}" fill="none" stroke="#8aa0b8" stroke-width="1.5" {"stroke-dasharray=\"5 4\"" if dash else ""} marker-end="url(#ar)"/>')
def txt(x,y,t,fs=10,fill=None,anchor="start",wt=800,ls=".6"):
    o.append(f'<text x="{x}" y="{y}" font-size="{fs}" font-weight="{wt}" letter-spacing="{ls}" text-anchor="{anchor}" fill="{fill or C["ink2"]}">{esc(t)}</text>')
o.append(f'<rect x="230" y="250" width="490" height="250" rx="10" fill="#fff" fill-opacity=".6" stroke="{C["green"]}" stroke-width="1.5" stroke-dasharray="5 4"/>')
txt(244,268,"AGENT SYSTEM",fill=C["green"])
line("M475 52 V76"); line("M585 111 H770"); line("M475 146 V170"); line("M475 220 V270"); line("M410 298 H170")
line("M475 326 V363 M475 363 H320 V400 M475 363 H630 V400"); line("M475 363 V400")
for cx in (320,475,630): line(f"M{cx} 456 V540")
line("M320 584 V612 H225 V640"); line("M475 584 V640"); line("M630 584 V612 H870 V640")
line("M230 415 H210"); line("M230 478 H190 V548 H170"); line("M720 278 H770"); line("M720 385 H770"); line("M720 470 H740 V505 H770"); line("M700 250 V195 H770")
line("M870 710 V752",dash=True)
box(400,0,150,52,["C1 · Chat UI"],"blue")
box(365,76,220,70,["C2 · Edge layer","WAF, DDoS, rate limits,","API gateway"],"blue")
box(770,76,210,70,["C3 · Identity provider","MFA and step-up"],"blue")
box(400,170,150,50,["C4 · Application API"],"blue",fs=12)
box(770,170,210,50,["C6 · PII redaction"],"blue")
box(20,270,150,56,["C5 · Authorisation","(checks the user)"],"blue",fs=12)
box(410,270,130,56,["C7 · Coordinator","agent"],"green",fs=12)
box(250,400,140,56,["C8 · Specialist A","accounts"],"green",fs=12); box(405,400,140,56,["C8 · Specialist B","cards"],"green",fs=12); box(560,400,140,56,["C8 · Specialist C","service requests"],"green",fs=12)
box(770,250,210,56,["C13 · Evaluation suite"],"green")
o.append(f'<rect x="770" y="330" width="320" height="110" rx="8" fill="{C["orangebg"]}" stroke="{C["orange"]}" stroke-width="1.5"/>')
txt(784,349,"C12 · MODEL LAYER",fill=C["orange"])
box(785,360,135,64,["Self-hosted","LLM"],"orange"); box(935,360,140,64,["Third-party","LLM API"],"orange")
o.append(f'<rect x="20" y="350" width="190" height="100" rx="8" fill="#fff" stroke="{C["blue"]}" stroke-width="1.5"/>')
txt(115,370,"C15 · Observability",fs=12,anchor="middle",wt=700,ls="0",fill=C["ink"])
box(28,380,86,62,["Prompts, agent","and tool calls"],"green",bold=False,fs=10.5); box(118,380,84,62,["CPU, memory,","disk"],"blue",bold=False,fs=10.5)
txt(115,468,"feeds SIEM and SOAR",fs=10.5,anchor="middle",wt=600,ls="0")
box(20,520,150,56,["C14 · Cost and","usage tracker"],"green",fs=12)
cx,cy,wd,h=770,490,160,64
o.append(f'<path d="M{cx} {cy+10} v{h-20} a{wd/2} 10 0 0 0 {wd} 0 v-{h-20} a{wd/2} 10 0 0 0 -{wd} 0 a{wd/2} 10 0 0 1 {wd} 0" fill="{C["bluebg"]}" stroke="{C["blue"]}" stroke-width="1.5"/>')
txt(cx+wd/2,cy+h/2+9,"C11 · Session store",fs=12,anchor="middle",wt=700,ls="0",fill=C["ink"])
txt(948,cy+28,"Conversation history",fs=11.5,wt=400,ls="0"); txt(948,cy+48,"Inter-agent shared state",fs=11.5,wt=400,ls="0")
for x,n in ((250,"A"),(405,"B"),(560,"C")): box(x,540,140,44,[f"C9 · Tool server {n}","(MCP)"],"green",fs=11.5)
def group(x,w,title,items):
    o.append(f'<rect x="{x}" y="640" width="{w}" height="70" rx="8" fill="{C["graybg"]}" stroke="{C["gray"]}" stroke-width="1.5"/>')
    txt(x+8,653,title,fs=9.5,fill=C["gray"])
    n=len(items); iw=(w-12-(n-1)*8)/n
    for i,t in enumerate(items):
        ix=x+6+i*(iw+8)
        o.append(f'<rect x="{ix}" y="660" width="{iw}" height="40" rx="5" fill="#fff" stroke="{C["gray"]}" stroke-width="1.2"/>')
        o.append(f'<text x="{ix+iw/2}" y="684" text-anchor="middle" font-size="11" fill="{C["ink"]}">{t}</text>')
group(140,170,"C10 · TIER 1",["Read-only lookups"]); group(330,290,"C10 · TIER 2",["Create records","Update records"]); group(660,420,"C10 · TIER 3 (human approval)",["Change address / limits","Send externally","Delete data"])
box(660,752,420,48,["C16 · Human approval and handoff console","Tier 3 actions wait here for a staff member; customers can reach a person"],"violet",fs=12)
o.append(f'<text x="880" y="746" font-size="10" fill="{C["violet"]}" font-weight="700">approve / reject</text>')
fig1="\n".join(o)
h1=HEAD+f'''<div class="canvas" id="fig1"><h2>Reference Architecture with Component IDs</h2>
<p class="s">The customer service agent used in this assessment. The IDs (C1 to C16) are used in the control matrix, guardrails and risk register. Generic multi-agent reference design; the firm and its systems are fictional.</p>
<svg width="1108" height="812" viewBox="0 0 1108 812" xmlns="http://www.w3.org/2000/svg"><defs><marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="#8aa0b8"/></marker></defs>{fig1}</svg>
<div class="key"><span><i style="border-color:#2a78d6;background:#e8f0fb"></i>Security and infrastructure</span><span><i style="border-color:#0f8f63;background:#e3f5ee"></i>Agent layer</span><span><i style="border-color:#c9601f;background:#fbeee4"></i>Model layer</span><span><i style="border-color:#85837c;background:#f1f1ef"></i>Backend systems by action tier</span><span><i style="border-color:#4a3aa7;background:#ece9f8"></i>Human oversight</span></div></div>'''

# ---------------- Figure 2: EU AI Act classification flow
o=[]
def fbox(x,y,w,h,title,sub,kind):
    o.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="9" fill="{C[kind+"bg"]}" stroke="{C[kind]}" stroke-width="1.6"/>')
    o.append(f'<text x="{x+14}" y="{y+22}" font-size="13" font-weight="700" fill="{C["ink"]}">{esc(title)}</text>')
    for i,s in enumerate(sub): o.append(f'<text x="{x+14}" y="{y+42+i*16}" font-size="11.5" fill="{C["ink2"]}">{esc(s)}</text>')
def arrow(d,label=None,lx=0,ly=0,col="#8aa0b8"):
    o.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="1.6" marker-end="url(#ar2)"/>')
    if label: o.append(f'<text x="{lx}" y="{ly}" font-size="11" font-weight="800" fill="{col if col!="#8aa0b8" else C["ink2"]}">{label}</text>')
fbox(20,10,560,74,"1. Is it an AI system under the Act?",["An LLM-based agent that infers from its input how to produce","outputs that influence actions: yes."],"blue")
fbox(20,118,560,74,"2. Is any prohibited practice (Art 5) intended?",["Manipulation, exploiting vulnerability, emotion inference: no.","Guardrail G-16 keeps it that way."],"blue")
fbox(20,226,560,92,"3. Does the use fall in an Annex III high-risk area?",["Closest areas: 5(b) creditworthiness / credit score, and","5(c) life and health insurance risk and pricing.","Scope excludes both (G-14); no tool exists for them. Answer: no."],"blue")
fbox(20,352,560,74,"4. Does it interact directly with people?",["Yes: customers chat with it. Art 50(1) disclosure applies","(since 2 Aug 2026). Guardrail G-15."],"blue")
fbox(20,460,560,116,"Result: not high-risk. Transparency tier plus literacy.",["Binding now: Art 50(1) disclosure, Art 4 AI literacy, Art 5 checks.","Voluntary design targets: Arts 9 to 15, 17 and deployer practice","(Art 26) applied as good practice (Art 95 idea).","Re-run this flow whenever scope changes (G-40, risk R-15)."],"green")
fbox(660,226,420,134,"If step 3 had been yes: high-risk path",["Obligations of Arts 8 to 27 apply (Annex III date after","the Omnibus: 2 Dec 2027). Deployer duties incl. log","retention (Art 26(6)), FRIA (Art 27) for 5(b) and 5(c),","conformity assessment, registration, serious-incident","reporting (Art 73). The firm would likely be provider too."],"red")
arrow("M300 84 V118"); arrow("M300 192 V226"); arrow("M300 318 V352","NO",312,340); arrow("M300 426 V460")
arrow("M580 270 H660","YES",600,262,C["red"])
o.append(f'<text x="34" y="107" font-size="0"></text>')
fig2="\n".join(o)
h2=f'''<div class="canvas" id="fig2"><h2>EU AI Act Classification Flow for the Service Agent</h2>
<p class="s">My reasoning for the fictional firm's agent, step by step. Interpretation for a learning project, not legal advice. Dates reflect the AI Omnibus as I read it; check the Official Journal before relying on them.</p>
<svg width="1100" height="590" viewBox="0 0 1100 590" xmlns="http://www.w3.org/2000/svg"><defs><marker id="ar2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="#8aa0b8"/></marker></defs>{fig2}</svg></div>'''

# ---------------- Figure 3: risk heat maps
BAND={"Low":"#e3f5ee","Medium":"#fdf3d8","High":"#f8d9c0","Critical":"#f1c0bb"}
def grid(title,key):
    cell={}
    for r in RISKS:
        l,i=(r["li"],r["ii"]) if key=="in" else (r["rl"],r["ri"])
        cell.setdefault((l,i),[]).append(r["id"].replace("R-",""))
    x0,y0,cw,ch=60,34,128,88
    s=[f'<text x="{x0}" y="18" font-size="14" font-weight="700" fill="{C["ink"]}">{title}</text>']
    for l in range(5,0,-1):
        for i in range(1,6):
            sc,band=sev(l,i); x=x0+(i-1)*cw; y=y0+(5-l)*ch
            s.append(f'<rect x="{x}" y="{y}" width="{cw}" height="{ch}" fill="{BAND[band]}" stroke="#fff" stroke-width="2"/>')
            ids=cell.get((l,i),[])
            for k,t in enumerate(ids):
                px=x+10+(k%4)*29; py=y+12+(k//4)*26
                s.append(f'<rect x="{px}" y="{py}" width="26" height="20" rx="10" fill="{C["violet"]}"/><text x="{px+13}" y="{py+14.5}" font-size="11" font-weight="700" fill="#fff" text-anchor="middle">{t}</text>')
    for v in range(1,6):
        s.append(f'<text x="{x0+(v-1)*cw+cw/2}" y="{y0+5*ch+18}" font-size="11.5" text-anchor="middle" fill="{C["ink2"]}">{v}</text>')
        s.append(f'<text x="{x0-12}" y="{y0+(5-v)*ch+ch/2+4}" font-size="11.5" text-anchor="end" fill="{C["ink2"]}">{v}</text>')
    s.append(f'<text x="{x0+2.5*cw}" y="{y0+5*ch+38}" font-size="11.5" text-anchor="middle" font-weight="700" fill="{C["ink2"]}">Impact</text>')
    s.append(f'<text transform="translate(16 {y0+2.5*ch}) rotate(-90)" font-size="11.5" text-anchor="middle" font-weight="700" fill="{C["ink2"]}">Likelihood</text>')
    return "\n".join(s)
g_in=grid("Inherent (before guardrails)","in"); g_re=grid("Residual target (if guardrails work as specified)","re")
h3=f'''<div class="canvas" id="fig3"><h2>Risk Heat Maps: Before and After Guardrails</h2>
<p class="s">The 20 risks in the register, numbered (R-01 appears as 01). Scores are my qualitative judgement for a hypothetical system. The right-hand map is a target that assumes every mapped guardrail is built and passes its test; nothing is built yet.</p>
<div style="display:flex;gap:36px"><svg width="720" height="520" viewBox="0 0 720 520" xmlns="http://www.w3.org/2000/svg">{g_in}</svg><svg width="720" height="520" viewBox="0 0 720 520" xmlns="http://www.w3.org/2000/svg">{g_re}</svg></div>
<div class="key"><span><i style="border-color:#bbb;background:#e3f5ee"></i>Low (1 to 5)</span><span><i style="border-color:#bbb;background:#fdf3d8"></i>Medium (6 to 11)</span><span><i style="border-color:#bbb;background:#f8d9c0"></i>High (12 to 19)</span><span><i style="border-color:#bbb;background:#f1c0bb"></i>Critical (20 to 25)</span></div></div>'''

for name,body,sel in (("01-architecture-component-ids",h1,"#fig1"),("02-eu-ai-act-classification-flow",h2,"#fig2"),("03-risk-heatmap",h3,"#fig3")):
    open(f"{TMP}/{name}.html","w").write(body+"</body></html>" if body.startswith("<!doctype") else HEAD+body+"</body></html>")
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(**({"executable_path":os.environ["CHROMIUM_PATH"]} if os.environ.get("CHROMIUM_PATH") else {}))
    pg=b.new_page(viewport={"width":1600,"height":1200},device_scale_factor=2)
    for name,body,sel in (("01-architecture-component-ids",h1,"#fig1"),("02-eu-ai-act-classification-flow",h2,"#fig2"),("03-risk-heatmap",h3,"#fig3")):
        pg.goto(f"file://{TMP}/{name}.html"); pg.locator(sel).screenshot(path=f"{OUT}/{name}.png")
    b.close()
print("figs ok")
