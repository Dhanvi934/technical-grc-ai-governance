# Articles

PDF copies of the five pieces I've published on my research Substack ([add your Substack link]). Substack is where they're first published. The copies here sit next to my study notes and projects, and each one has a matching note in [`/learnings`](../learnings).

| # | Title | Published | Study note |
|---|---|---|---|
| 1 | [Securing Canada's Critical Infrastructure: Why Network Segmentation, Backup Resilience, and Secure Remote Access Are Governance Imperatives](./01-canada-critical-infrastructure-segmentation-backup-remote-access.pdf) | 10 Sep 2026 | [01](../learnings/01-canada-critical-infrastructure-controls.md) |
| 2 | [Canada Has No AI Law. Here's What's Actually Governing AI Right Now.](./02-canada-has-no-ai-law.pdf) | 26 Sep 2026 | [02](../learnings/02-canada-ai-governance-patchwork.md) |
| 3 | [The EU Has Three Cybersecurity Laws. And They're Actually Designed to Work Together.](./03-eu-three-cybersecurity-laws.pdf) | 29 Sep 2026 | [03](../learnings/03-eu-cra-nis2-dora.md) |
| 4 | [Beyond the Checklist: What CSCRF, CERT-In, and DPDP Actually Require You to Build](./04-beyond-the-checklist-cscrf-cert-in-dpdp.pdf) | 5 Oct 2026 | [04](../learnings/04-india-layered-cyber-governance.md) |
| 5 | [The Identity Crisis of Agentic AI: Why Machine Credentials & Continuous SIEM Telemetry Are the New Security Perimeter](./05-identity-crisis-of-agentic-ai.pdf) | 11 Oct 2026 | [05](../learnings/05-agentic-ai-and-nhis.md) |

## A note on these copies

The Substack version is the published one. If I correct something after publishing, I'll update both places. Where an article marks something as my interpretation or as unverified, that carries over from the original, and the matching study note lists what I still want to verify.
